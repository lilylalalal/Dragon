const Dragon = require('./dragon')
const FriendlyDragon = require('./friendly-dragon')
const EvilDragon =require('./evil-dragon')



const alldragons = require('./notInuse-all-dragons');
const falkor = alldragons.falkor;
const smaug = alldragons.smaug;
const allDragons = alldragons.allDragons;


console.log(falkor); // "Falkor"
console.log(smaug); // "Smaug"
console.log(allDragons); // 